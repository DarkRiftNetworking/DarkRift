var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings =
[
    [ "PluginSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings_1_1_plugin_settings.html", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings_1_1_plugin_settings" ],
    [ "LoadByDefault", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings.html#a8237992d7adb91bb5e415131acbc0885", null ],
    [ "Plugins", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings.html#a53a5fb2802765ad31bfcf57906062a1d", null ]
];