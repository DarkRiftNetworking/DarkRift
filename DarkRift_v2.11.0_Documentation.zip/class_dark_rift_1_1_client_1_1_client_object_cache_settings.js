var class_dark_rift_1_1_client_1_1_client_object_cache_settings =
[
    [ "DontUseCache", "class_dark_rift_1_1_client_1_1_client_object_cache_settings.html#afbb20f09c5880667d2d2f3726e6035e8", null ],
    [ "MaxMessageReceivedEventArgs", "class_dark_rift_1_1_client_1_1_client_object_cache_settings.html#ab6930823b7d1cadbc72b3f4c00ea2035", null ]
];