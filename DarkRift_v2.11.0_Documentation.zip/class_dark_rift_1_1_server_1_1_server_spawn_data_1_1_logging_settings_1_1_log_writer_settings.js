var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings =
[
    [ "LogWriterSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings.html#a827f5ef2ac523665be414332e436b0dd", null ],
    [ "LogLevels", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings.html#a9c6e8c87cc876540ad82e14e021e4b12", null ],
    [ "Name", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings.html#a31a5a092a7fc4ab5742247dd42c75638", null ],
    [ "Settings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings.html#a0928bd2b6c156dbecd534cdfd819f025", null ],
    [ "Type", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings.html#a647419c6fef8805ef3438854753b3f07", null ]
];