var class_dark_rift_1_1_server_1_1_server_object_cache_settings =
[
    [ "DontUseCache", "class_dark_rift_1_1_server_1_1_server_object_cache_settings.html#afd0a16f62aa3caba75a9911a7ddf98a1", null ],
    [ "MaxMessageReceivedEventArgs", "class_dark_rift_1_1_server_1_1_server_object_cache_settings.html#a24807dd46832b7aebf944ab61b515490", null ],
    [ "MaxServerMessageReceivedEventArgs", "class_dark_rift_1_1_server_1_1_server_object_cache_settings.html#a80d505e5652a7da3f32381f978d72977", null ]
];