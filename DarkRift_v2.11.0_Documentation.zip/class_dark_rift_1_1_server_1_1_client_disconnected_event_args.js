var class_dark_rift_1_1_server_1_1_client_disconnected_event_args =
[
    [ "ClientDisconnectedEventArgs", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#a88e3e861701caad204ace6734ad62bef", null ],
    [ "GetRemoteEndPoint", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#aae000ffac9a6208cc9162000ccdff32e", null ],
    [ "Client", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#ab510099bc1c2d68d0aa0fb9e925b2e02", null ],
    [ "Error", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#a6e8a9eebfe666f7780f6b8f6bffbf14a", null ],
    [ "Exception", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#a8a5269ca6f560cd8cfe461d924416ca7", null ],
    [ "LocalDisconnect", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#a67e098d75ad65db1c118ac9ca8112992", null ],
    [ "RemoteEndPoints", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#af6ed89267b4b52f34c42f794dbd16bf0", null ],
    [ "RemoteTcpEndPoint", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#aa7b8e53b971b57d1094f61b01e983144", null ],
    [ "RemoteUdpEndPoint", "class_dark_rift_1_1_server_1_1_client_disconnected_event_args.html#aa4e0d35c94690d7bf4e9a82b4407b923", null ]
];