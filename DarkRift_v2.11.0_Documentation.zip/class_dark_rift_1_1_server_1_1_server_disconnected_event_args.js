var class_dark_rift_1_1_server_1_1_server_disconnected_event_args =
[
    [ "ServerDisconnectedEventArgs", "class_dark_rift_1_1_server_1_1_server_disconnected_event_args.html#a6684932c3641ca137532143463d10a7e", null ],
    [ "GetRemoteEndPoint", "class_dark_rift_1_1_server_1_1_server_disconnected_event_args.html#a9b29fc35d71b2642b22682e267c5771d", null ],
    [ "Error", "class_dark_rift_1_1_server_1_1_server_disconnected_event_args.html#a84799f0fd2438a30b701a38537918c78", null ],
    [ "Exception", "class_dark_rift_1_1_server_1_1_server_disconnected_event_args.html#affce199fff21b3b2b021e01fda2f762e", null ],
    [ "RemoteServer", "class_dark_rift_1_1_server_1_1_server_disconnected_event_args.html#a064e4630b6cf4aad5cb2b33a8c5cac61", null ]
];