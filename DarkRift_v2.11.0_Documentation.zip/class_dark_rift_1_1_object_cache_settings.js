var class_dark_rift_1_1_object_cache_settings =
[
    [ "DontUseCache", "class_dark_rift_1_1_object_cache_settings.html#a850cec80ee0fb24675690c8f7e6fec8c", null ],
    [ "ExtraLargeMemoryBlockSize", "class_dark_rift_1_1_object_cache_settings.html#a15512dbe3674c4a422bc48361d6c1175", null ],
    [ "ExtraSmallMemoryBlockSize", "class_dark_rift_1_1_object_cache_settings.html#afcf3b8d6ba8fb5348c13a743dddf5722", null ],
    [ "LargeMemoryBlockSize", "class_dark_rift_1_1_object_cache_settings.html#aa5a09991aa9904930af5fc07b3255967", null ],
    [ "MaxActionDispatcherTasks", "class_dark_rift_1_1_object_cache_settings.html#ac05c19693d1edb8ab1dcfe0134b9543f", null ],
    [ "MaxAutoRecyclingArrays", "class_dark_rift_1_1_object_cache_settings.html#a0f720133fcc90865c99783c54b116233", null ],
    [ "MaxExtraLargeMemoryBlocks", "class_dark_rift_1_1_object_cache_settings.html#a9103bf8956e2244e4169cd0e309239a9", null ],
    [ "MaxExtraSmallMemoryBlocks", "class_dark_rift_1_1_object_cache_settings.html#a147711eadceac3f70e94ab5356ce3376", null ],
    [ "MaxLargeMemoryBlocks", "class_dark_rift_1_1_object_cache_settings.html#ac97a00d599acf77358c13e9a3a065f74", null ],
    [ "MaxMediumMemoryBlocks", "class_dark_rift_1_1_object_cache_settings.html#a0d5ee8557a66f41945a23e29758e6fd8", null ],
    [ "MaxMessageBuffers", "class_dark_rift_1_1_object_cache_settings.html#a6ead6b0b53d3457d7bf9462edb34de7d", null ],
    [ "MaxMessages", "class_dark_rift_1_1_object_cache_settings.html#abec4ef125faa8c16d217abdf38752237", null ],
    [ "MaxReaders", "class_dark_rift_1_1_object_cache_settings.html#a90b2267419d202753295932bdc47115a", null ],
    [ "MaxSmallMemoryBlocks", "class_dark_rift_1_1_object_cache_settings.html#ab6c1a1be563a376c998546d6416eaba6", null ],
    [ "MaxSocketAsyncEventArgs", "class_dark_rift_1_1_object_cache_settings.html#a9b76749ce94c74be5e35a92d50489012", null ],
    [ "MaxWriters", "class_dark_rift_1_1_object_cache_settings.html#a1d47c7e5536bc9cb94e0e2cd5885976a", null ],
    [ "MediumMemoryBlockSize", "class_dark_rift_1_1_object_cache_settings.html#a676995b670dbb4c4eadc4496b2771ed9", null ],
    [ "SmallMemoryBlockSize", "class_dark_rift_1_1_object_cache_settings.html#a785ae62ad9f711484fb84a599d8a2720", null ]
];