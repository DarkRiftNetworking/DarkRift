var class_dark_rift_1_1_server_1_1_server_registry_connector =
[
    [ "ServerRegistryConnector", "class_dark_rift_1_1_server_1_1_server_registry_connector.html#a9949c122ce18ba95800f2f5291d06051", null ],
    [ "HandleServerJoin", "class_dark_rift_1_1_server_1_1_server_registry_connector.html#a7ed015209313d22acc90d17fde321e71", null ],
    [ "HandleServerLeave", "class_dark_rift_1_1_server_1_1_server_registry_connector.html#af69333411250696a2401c75f425b61e8", null ],
    [ "RemoteServerManager", "class_dark_rift_1_1_server_1_1_server_registry_connector.html#a7b3eadc91b2c3581ab4c84c7e26ff980", null ],
    [ "ServerRegistryConnectorManager", "class_dark_rift_1_1_server_1_1_server_registry_connector.html#a63133518006dba47c61ecdc683a1dfb9", null ]
];