var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings =
[
    [ "Address", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#aac6f95d879f9d83c5616a1adae9ce556", null ],
    [ "IPVersion", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#af69bffd78a23ca43dac479b492abd0e1", null ],
    [ "MaxStrikes", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#a597ddcf3ad7db84966a81bd29bcb5105", null ],
    [ "NoDelay", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#a669b02851ea3a48082ca7c4fdb590369", null ],
    [ "Port", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#a3c6a42d5856009d79994e96c5a2d3aaf", null ],
    [ "ReconnectAttempts", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#a5437bd8cabc9693bc747adec043c7d06", null ],
    [ "ServerGroup", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#ac12aa4d50f68edf92dc3890f4b1ec0bb", null ],
    [ "UseFallbackNetworking", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_settings.html#ab07329bb9512a203a75f3bc9566646f8", null ]
];