var class_dark_rift_1_1_server_1_1_dark_rift_info =
[
    [ "ServerType", "class_dark_rift_1_1_server_1_1_dark_rift_info.html#a2b220456c383360d765c29f3fa419fc5", null ],
    [ "DarkRiftInfo", "class_dark_rift_1_1_server_1_1_dark_rift_info.html#ac74801f548b808e7752072e7902c1101", null ],
    [ "DocumentationRoot", "class_dark_rift_1_1_server_1_1_dark_rift_info.html#adbe19bbac730a94faa3c5b9d0bbe8b3f", null ],
    [ "StartTime", "class_dark_rift_1_1_server_1_1_dark_rift_info.html#a05cd80279a7825381770959a2db7c300", null ],
    [ "Type", "class_dark_rift_1_1_server_1_1_dark_rift_info.html#a9c93b6efeb2354228bdc47926829f53e", null ],
    [ "Version", "class_dark_rift_1_1_server_1_1_dark_rift_info.html#a9a40f95564f04963cffd781ac215a7b5", null ]
];