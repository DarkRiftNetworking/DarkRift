var class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker =
[
    [ "RankingMatchmaker", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a7fa67a8f52fa6a93cb7a626464190882", null ],
    [ "Dispose", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#ac1eb2847156f4f0438924b811d0f17df", null ],
    [ "Enqueue", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#adc2b375ac36cdad10ef81786281da937", null ],
    [ "EnqueueGroup", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a9e2afc70425149362b43f9e06d33ee4f", null ],
    [ "EnqueueGroup", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a1445ad2e6bbd04a570a437a339b54301", null ],
    [ "GetSuitabilityMetric", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a083ef104001924d23a7ef97dc994ce28", null ],
    [ "PerformFullSearch", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a7166ade498813ef055deb599d2ef5b5e", null ],
    [ "DiscardThreshold", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a2e5b818b0abb2f0d63ed8885dfa756c4", null ],
    [ "EntitiesPerGroup", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#a7351a11d40610a4ff30621b5b66c93de", null ],
    [ "GroupDiscardThreshold", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#aa9de2d1e7d36f5a29b33d0a941de2457", null ],
    [ "TickPeriod", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#ac35a0057272949344a1d7967b236f343", null ],
    [ "GroupFormed", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_ranking_matchmaker.html#ac96868828374228a51d46a90be7bd62a", null ]
];