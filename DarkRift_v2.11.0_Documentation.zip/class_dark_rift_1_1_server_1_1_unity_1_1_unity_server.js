var class_dark_rift_1_1_server_1_1_unity_1_1_unity_server =
[
    [ "Close", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a46cff55424636cc1fdd921df2f77f974", null ],
    [ "Create", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a85c3e21f839a99bb16a2dec009031ffd", null ],
    [ "Address", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a231ae4190b13733e895490d94dc17090", null ],
    [ "Databases", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a3e607c311f9835dfe681a0cdc7d5a6e2", null ],
    [ "DataDirectory", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a7402325ef76827de8e58af9ca2c38f4e", null ],
    [ "LoadByDefault", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a6e668698862f3349732469242421374a", null ],
    [ "LogFileString", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a7407ee6a3aa7dc74e225fc2fcc1b60a4", null ],
    [ "LogToDebug", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a808e6ce6b90d1ad8bb0784b3a5d77461", null ],
    [ "LogToFile", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a2e01095403e40ad25f654c89af066335", null ],
    [ "LogToUnityConsole", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a05a63dc60e2fa75c03b53202e2f387ab", null ],
    [ "MaxCachedActionDispatcherTasks", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a7132ec77a32310a5d01975ac7fff6566", null ],
    [ "MaxCachedMessages", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a8e9e07671cf87d15e410110abf550ef2", null ],
    [ "MaxCachedReaders", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a34f37487ca362e6921bdaa810fd327fb", null ],
    [ "MaxCachedSocketAsyncEventArgs", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a681b1a000d1e46bf9e461f4ac317c4f5", null ],
    [ "MaxCachedWriters", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#a14861635aeed2ec2145e0e1274c00323", null ],
    [ "MaxStrikes", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#ad96fe427a88ac4ae9fea630ac235dedf", null ],
    [ "Plugins", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#af7d406e29d57b005af2ca85287872b4a", null ],
    [ "Port", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#ae6fdd19d464cd5657343562c81d22378", null ],
    [ "Server", "class_dark_rift_1_1_server_1_1_unity_1_1_unity_server.html#aa03786ec0cf5d97df86e240e5ee7e801", null ]
];