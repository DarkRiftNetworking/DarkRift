var class_dark_rift_1_1_server_1_1_server_left_event_args =
[
    [ "ServerLeftEventArgs", "class_dark_rift_1_1_server_1_1_server_left_event_args.html#af9669505988880f999bb6a39ed1b93f2", null ],
    [ "ID", "class_dark_rift_1_1_server_1_1_server_left_event_args.html#a08b30d2179e10c912dd8d109da2b27b5", null ],
    [ "RemoteServer", "class_dark_rift_1_1_server_1_1_server_left_event_args.html#a0f7d089a83bdcd063fad5299603929c0", null ],
    [ "ServerGroup", "class_dark_rift_1_1_server_1_1_server_left_event_args.html#a158abbdfc539098e3c2e74bd78f38305", null ]
];