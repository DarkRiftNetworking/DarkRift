var class_dark_rift_1_1_round_trip_time_helper =
[
    [ "RoundTripTimeHelper", "class_dark_rift_1_1_round_trip_time_helper.html#aab4792750d24af3daed365ab1137035f", null ],
    [ "LatestRtt", "class_dark_rift_1_1_round_trip_time_helper.html#a58d28c4e6764a6a873b3413b0eb16353", null ],
    [ "RttSampleCount", "class_dark_rift_1_1_round_trip_time_helper.html#a99efb8f7fdc4d2f91613c3cd6d721887", null ],
    [ "SmoothedRtt", "class_dark_rift_1_1_round_trip_time_helper.html#ad6968753fe92902abad8f7a9abcc44f3", null ],
    [ "SmothedRtt", "class_dark_rift_1_1_round_trip_time_helper.html#a25d1fa9fab487e4bd5d6931992648ea7", null ]
];