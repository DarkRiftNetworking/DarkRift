var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_database_settings =
[
    [ "DatabaseConnectionData", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_database_settings_1_1_database_connection_data.html", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_database_settings_1_1_database_connection_data" ],
    [ "Databases", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_database_settings.html#a95939995b0234092bd342ad19cbf27d5", null ]
];