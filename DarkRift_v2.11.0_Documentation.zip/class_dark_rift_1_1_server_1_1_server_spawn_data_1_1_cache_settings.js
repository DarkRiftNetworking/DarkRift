var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings =
[
    [ "MaxActionDispatcherTasks", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a17f3bacf1759389b317fd8181265037f", null ],
    [ "MaxAutoRecyclingArrays", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a634291c656482d8a2db5808c46f1115e", null ],
    [ "MaxCachedMessages", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a08a997631e70ec58f1e6875bcd20c919", null ],
    [ "MaxCachedReaders", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a7b7a5a00f53af8598e13a53786e65b4e", null ],
    [ "MaxCachedSocketAsyncEventArgs", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a72007480f5516e674d1e6426b7c2605c", null ],
    [ "MaxCachedWriters", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a3ae9eb1e5a962fa39b9470dc23de0f00", null ],
    [ "ObjectCacheSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a6469f9504cffd5098453200703496c56", null ],
    [ "ServerObjectCacheSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_cache_settings.html#a573367fc4f5c75eff1b4a73d2383eda1", null ]
];