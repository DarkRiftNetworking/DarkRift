var class_dark_rift_1_1_server_1_1_client_connected_event_args =
[
    [ "ClientConnectedEventArgs", "class_dark_rift_1_1_server_1_1_client_connected_event_args.html#a441cdfcd3997549bcc29669d35a22d36", null ],
    [ "GetRemoteEndPoint", "class_dark_rift_1_1_server_1_1_client_connected_event_args.html#af48dc4130f0669aeae1a7a56e078c5bc", null ],
    [ "Client", "class_dark_rift_1_1_server_1_1_client_connected_event_args.html#a2339ee26c67cbc0a47ebcf38262764d4", null ],
    [ "RemoteEndPoints", "class_dark_rift_1_1_server_1_1_client_connected_event_args.html#a2676cb03db07b79ea6bf3bcdf3d516c3", null ],
    [ "RemoteTcpEndPoint", "class_dark_rift_1_1_server_1_1_client_connected_event_args.html#abc275ccf50b8a599d12c648312fa27c3", null ],
    [ "RemoteUdpEndPoint", "class_dark_rift_1_1_server_1_1_client_connected_event_args.html#ac8a2800ec3d8aaa6eab9227f50106bc6", null ]
];