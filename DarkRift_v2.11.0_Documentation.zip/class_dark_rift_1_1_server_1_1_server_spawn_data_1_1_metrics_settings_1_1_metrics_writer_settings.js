var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_metrics_settings_1_1_metrics_writer_settings =
[
    [ "Settings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_metrics_settings_1_1_metrics_writer_settings.html#ac05ac22c9548cb65e9ffabbe5e411562", null ],
    [ "Type", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_metrics_settings_1_1_metrics_writer_settings.html#a2344ac78793414654472f0406a8995cb", null ]
];