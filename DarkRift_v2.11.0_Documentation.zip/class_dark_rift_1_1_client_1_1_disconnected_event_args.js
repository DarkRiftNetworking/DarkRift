var class_dark_rift_1_1_client_1_1_disconnected_event_args =
[
    [ "Error", "class_dark_rift_1_1_client_1_1_disconnected_event_args.html#ab3b912a7e66d19b8a2bcb73640894d72", null ],
    [ "Exception", "class_dark_rift_1_1_client_1_1_disconnected_event_args.html#acc77cbe7d083e9457bcacabf8861bed3", null ],
    [ "LocalDisconnect", "class_dark_rift_1_1_client_1_1_disconnected_event_args.html#a8e59c19d6b4fe1639afb9a78c1af3faa", null ]
];