var class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_matchmaking_state_changed_event_args =
[
    [ "MatchmakingStateChangedEventArgs", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_matchmaking_state_changed_event_args.html#acc12f76d0358aef07adb206d1a20d3d5", null ],
    [ "Entities", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_matchmaking_state_changed_event_args.html#ac55b65fb76c1421af7ee7080a8d6610f", null ],
    [ "MatchmakingState", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_matchmaking_state_changed_event_args.html#a0ba9bf8604ac791a32de3d8e3dae8a85", null ],
    [ "SubGroups", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_matchmaking_state_changed_event_args.html#a841764474ce0ae70fc5d1e3132aed46b", null ]
];