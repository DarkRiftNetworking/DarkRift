var class_dark_rift_1_1_server_1_1_server_message_received_event_args =
[
    [ "Create", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#a4aedf414d29545958e9f0037f29fa0ff", null ],
    [ "Dispose", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#a7cc534cb4ed29590e17fcc06884a19d8", null ],
    [ "GetMessage", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#a3207e8da0689c6c9878d5bac1ae446f7", null ],
    [ "RemoteServer", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#ac55b861ed0f7cb698dc934f4c5aa2261", null ],
    [ "SendMode", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#ae869548227368f7633ecc114903c366d", null ],
    [ "ServerGroup", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#ad0b224d556a71e65efb205192f13c174", null ],
    [ "Tag", "class_dark_rift_1_1_server_1_1_server_message_received_event_args.html#ad42e5a8d7387f3afa581c509e79eeac6", null ]
];