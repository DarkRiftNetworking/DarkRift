var class_dark_rift_1_1_server_1_1_upgrade_event_args =
[
    [ "UpgradeEventArgs", "class_dark_rift_1_1_server_1_1_upgrade_event_args.html#a2f9f4a6c4c6f7852f95c7d121c91df66", null ],
    [ "PreviousVersion", "class_dark_rift_1_1_server_1_1_upgrade_event_args.html#a7645a40a256c9478ac163784fd6bf609", null ]
];