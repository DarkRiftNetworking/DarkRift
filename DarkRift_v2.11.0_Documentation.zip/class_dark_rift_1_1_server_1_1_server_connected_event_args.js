var class_dark_rift_1_1_server_1_1_server_connected_event_args =
[
    [ "ServerConnectedEventArgs", "class_dark_rift_1_1_server_1_1_server_connected_event_args.html#afa2483a7809aaa332540400bc82cf61c", null ],
    [ "GetRemoteEndPoint", "class_dark_rift_1_1_server_1_1_server_connected_event_args.html#a89ea55e7b4519348c7700af8ef89b928", null ],
    [ "RemoteServer", "class_dark_rift_1_1_server_1_1_server_connected_event_args.html#ac4fc47f8faeac3346b0af5360e7d9967", null ]
];