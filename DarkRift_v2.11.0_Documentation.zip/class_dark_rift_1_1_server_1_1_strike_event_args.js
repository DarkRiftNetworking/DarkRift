var class_dark_rift_1_1_server_1_1_strike_event_args =
[
    [ "StrikeEventArgs", "class_dark_rift_1_1_server_1_1_strike_event_args.html#adfb7fb50ee8979801f46639f98080f7c", null ],
    [ "Forgive", "class_dark_rift_1_1_server_1_1_strike_event_args.html#ae6f2556d1da1e7e377438e3f8267982f", null ],
    [ "Forgiven", "class_dark_rift_1_1_server_1_1_strike_event_args.html#a4a137f6f9b3c5d68064045dcdc10c008", null ],
    [ "Message", "class_dark_rift_1_1_server_1_1_strike_event_args.html#a353820ec95a3b2901acd6e7750b31f72", null ],
    [ "Reason", "class_dark_rift_1_1_server_1_1_strike_event_args.html#aaebfa4b9768bb58f6eba01df097c8722", null ],
    [ "Weight", "class_dark_rift_1_1_server_1_1_strike_event_args.html#a6255810e1960b084c97bcdbf2b2885b8", null ]
];