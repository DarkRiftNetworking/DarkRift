var class_dark_rift_1_1_serialize_event =
[
    [ "SerializeEvent", "class_dark_rift_1_1_serialize_event.html#a7b7ac7bfb98fa6e8aa1df32ac474ef0e", null ],
    [ "Writer", "class_dark_rift_1_1_serialize_event.html#a5d18910432949695d1919d94abde0c66", null ]
];