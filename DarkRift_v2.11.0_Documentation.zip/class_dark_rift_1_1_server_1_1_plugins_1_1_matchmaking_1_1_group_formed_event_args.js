var class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_group_formed_event_args =
[
    [ "GroupFormedEventArgs", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_group_formed_event_args.html#aa0fa58e735611a5ae045439724d730a5", null ],
    [ "Group", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_group_formed_event_args.html#a06907980c5832ad8a4279e5a989936aa", null ],
    [ "SubGroups", "class_dark_rift_1_1_server_1_1_plugins_1_1_matchmaking_1_1_group_formed_event_args.html#a4e7582f0c2c8931a61748d73d7d22f0b", null ]
];