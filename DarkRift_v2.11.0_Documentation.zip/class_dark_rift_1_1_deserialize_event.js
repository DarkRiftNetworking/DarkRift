var class_dark_rift_1_1_deserialize_event =
[
    [ "DeserializeEvent", "class_dark_rift_1_1_deserialize_event.html#a316b5199f0560e2a73d6d0c3c366eaaa", null ],
    [ "Reader", "class_dark_rift_1_1_deserialize_event.html#a58000edca5db2bced662daec38dafd0f", null ]
];