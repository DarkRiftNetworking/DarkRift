var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings =
[
    [ "ServerRegistryConnectorSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings_1_1_server_registry_connector_settings.html", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings_1_1_server_registry_connector_settings" ],
    [ "ServerRegistrySettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings.html#ac0bb595bc9bf309dd5ffcd6fe71887a0", null ],
    [ "AdvertisedHost", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings.html#af942ecededcc0028e5f32411436b360b", null ],
    [ "AdvertisedPort", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings.html#afc3a83176cbdb48a89fb1547f17644cb", null ],
    [ "ServerRegistryConnector", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_server_registry_settings.html#aa248f017e6b84612680c73018a1996ad", null ]
];