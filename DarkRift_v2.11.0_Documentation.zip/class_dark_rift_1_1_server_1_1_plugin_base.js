var class_dark_rift_1_1_server_1_1_plugin_base =
[
    [ "PluginBase", "class_dark_rift_1_1_server_1_1_plugin_base.html#aa22b4a58a5cc669bd2d6b351842534d7", null ],
    [ "CreateOneShotTimer", "class_dark_rift_1_1_server_1_1_plugin_base.html#ab963f9f192ab4fde5e3e628d97e91df3", null ],
    [ "CreateTimer", "class_dark_rift_1_1_server_1_1_plugin_base.html#aa9773221e07341d8e291d7071b80c7d6", null ],
    [ "Dispose", "class_dark_rift_1_1_server_1_1_plugin_base.html#a742e1e1c0c952023bbfd30da04860419", null ],
    [ "Dispose", "class_dark_rift_1_1_server_1_1_plugin_base.html#a9c7574f3f2cc7567a43d03f364a4e335", null ],
    [ "DatabaseManager", "class_dark_rift_1_1_server_1_1_plugin_base.html#ac313220f4b560c333e79d17fb6368292", null ],
    [ "Dispatcher", "class_dark_rift_1_1_server_1_1_plugin_base.html#a68f5484bd7b93f73b8d709001f603b44", null ],
    [ "Logger", "class_dark_rift_1_1_server_1_1_plugin_base.html#a40c5ee2c91ec5e9fd9c5bc58f991e6aa", null ],
    [ "LogManager", "class_dark_rift_1_1_server_1_1_plugin_base.html#a7c80de77c9cc3c620569ea920c69c482", null ],
    [ "Name", "class_dark_rift_1_1_server_1_1_plugin_base.html#acdb2bd4200f7d13d1262acb0115d1d84", null ],
    [ "ServerInfo", "class_dark_rift_1_1_server_1_1_plugin_base.html#a67ebbbc984f4a8e569b8dfca37900843", null ],
    [ "ThreadHelper", "class_dark_rift_1_1_server_1_1_plugin_base.html#ab767162e9135ff16ea383355d41ee34e", null ],
    [ "Version", "class_dark_rift_1_1_server_1_1_plugin_base.html#a25703a687919f3080f3680c4dbe5fd39", null ]
];