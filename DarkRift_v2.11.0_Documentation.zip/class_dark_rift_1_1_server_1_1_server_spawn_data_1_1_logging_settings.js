var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings =
[
    [ "LogWriterSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings.html", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings_1_1_log_writer_settings" ],
    [ "LoggingSettings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings.html#ab67b2e29cf65f9045c0adcf2c66b8a66", null ],
    [ "LogWriters", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings.html#a6f67bb19cb36e69b0ea21fc3fb9789ab", null ],
    [ "StartupLogLevels", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_logging_settings.html#a343823992eeef8478f4c023e9d8a6bb2", null ]
];