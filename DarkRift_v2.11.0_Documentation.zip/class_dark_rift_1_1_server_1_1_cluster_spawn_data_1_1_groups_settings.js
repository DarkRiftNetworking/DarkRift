var class_dark_rift_1_1_server_1_1_cluster_spawn_data_1_1_groups_settings =
[
    [ "GroupSettings", "class_dark_rift_1_1_server_1_1_cluster_spawn_data_1_1_groups_settings_1_1_group_settings.html", "class_dark_rift_1_1_server_1_1_cluster_spawn_data_1_1_groups_settings_1_1_group_settings" ],
    [ "Groups", "class_dark_rift_1_1_server_1_1_cluster_spawn_data_1_1_groups_settings.html#af9cd124f77d6b56c0af497e2b0b72eef", null ]
];