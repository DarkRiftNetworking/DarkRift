var class_dark_rift_1_1_server_1_1_server_joined_event_args =
[
    [ "ServerJoinedEventArgs", "class_dark_rift_1_1_server_1_1_server_joined_event_args.html#ab0ade2a5ae369ec5d02a41214b063107", null ],
    [ "ID", "class_dark_rift_1_1_server_1_1_server_joined_event_args.html#a6d79ccd5b9a619b4823d1d9ea27f155a", null ],
    [ "RemoteServer", "class_dark_rift_1_1_server_1_1_server_joined_event_args.html#a905cb8c349c7583891c2e757819fcd25", null ],
    [ "ServerGroup", "class_dark_rift_1_1_server_1_1_server_joined_event_args.html#ab83b5f694e288e13cf672d383a85269b", null ]
];