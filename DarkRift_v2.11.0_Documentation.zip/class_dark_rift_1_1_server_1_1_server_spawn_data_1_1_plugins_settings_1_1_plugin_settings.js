var class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings_1_1_plugin_settings =
[
    [ "Load", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings_1_1_plugin_settings.html#a624e39906d823e05ca97a7299d5c2cc9", null ],
    [ "Settings", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings_1_1_plugin_settings.html#a8dfd6029770093f23cdd066a8308d93e", null ],
    [ "Type", "class_dark_rift_1_1_server_1_1_server_spawn_data_1_1_plugins_settings_1_1_plugin_settings.html#a4fff489cb9505502b690c3547061f2e4", null ]
];